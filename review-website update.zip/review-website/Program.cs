using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using review_website.Data;
using review_website.Models;
using System;
using System.Linq;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add database context.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add authentication services.
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
    });

var app = builder.Build();

// Seed the database with test users.
SeedDatabase(app);

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

void SeedDatabase(WebApplication app)
{
    using (var scope = app.Services.CreateScope())
    {
        var services = scope.ServiceProvider;
        var context = services.GetRequiredService<ApplicationDbContext>();

        // Ensure database is created.
        context.Database.EnsureCreated();

        // Look for any users already in the database.
        if (context.Users.Any())
        {
            return;   // Database has been seeded.
        }

        context.Users.AddRange(
            new User
            {
                Username = "admin",
                Password = "adminpassword", // For simplicity, plaintext passwords; in real scenarios, use hashed passwords.
                Role = "Admin"
            },
            new User
            {
                Username = "editor",
                Password = "editorpassword",
                Role = "Editor"
            },
            new User
            {
                Username = "user",
                Password = "userpassword",
                Role = "User"
            }
        );

        context.SaveChanges();
    }
}
