﻿namespace review_website.Enums
{
    public enum Roles
    {
        Admin,
        User,
        Editor
    }
}
