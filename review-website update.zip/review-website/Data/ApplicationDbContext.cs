﻿using Microsoft.EntityFrameworkCore;
using review_website.Models;

namespace review_website.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) {}
        public DbSet<User> Users { get; set; }
    }
}
